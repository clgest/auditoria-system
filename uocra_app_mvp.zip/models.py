import sqlite3, os
from werkzeug.security import generate_password_hash, check_password_hash
from datetime import datetime

DB_PATH = os.path.join(os.path.dirname(__file__), "uocra.db")

def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn

def init_db():
    db = get_db()
    db.executescript("""
    CREATE TABLE IF NOT EXISTS usuarios (
        id        INTEGER PRIMARY KEY AUTOINCREMENT,
        email     TEXT UNIQUE NOT NULL,
        password  TEXT NOT NULL,
        nombre    TEXT NOT NULL,
        rol       TEXT NOT NULL DEFAULT 'cliente',
        activo    INTEGER NOT NULL DEFAULT 1,
        creado_en TEXT DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS empresas (
        id       INTEGER PRIMARY KEY AUTOINCREMENT,
        nombre   TEXT NOT NULL,
        cuit     TEXT,
        activa   INTEGER NOT NULL DEFAULT 1
    );

    CREATE TABLE IF NOT EXISTS usuario_empresa (
        usuario_id INTEGER REFERENCES usuarios(id),
        empresa_id INTEGER REFERENCES empresas(id),
        PRIMARY KEY (usuario_id, empresa_id)
    );

    CREATE TABLE IF NOT EXISTS empleados (
        id            INTEGER PRIMARY KEY AUTOINCREMENT,
        empresa_id    INTEGER NOT NULL REFERENCES empresas(id),
        legajo        TEXT NOT NULL,
        nombre        TEXT NOT NULL,
        cuil          TEXT,
        categoria     TEXT DEFAULT 'AYUDANTE',
        jornada       TEXT DEFAULT 'JORNADA COMPLETA',
        fecha_ingreso TEXT,
        estado        TEXT DEFAULT 'A',
        convenio      TEXT DEFAULT 'OBREROS DE LA CONSTRUCCION',
        cp            TEXT DEFAULT '4000',
        activo        INTEGER DEFAULT 1,
        UNIQUE(empresa_id, legajo)
    );

    CREATE TABLE IF NOT EXISTS novedades (
        id          INTEGER PRIMARY KEY AUTOINCREMENT,
        empresa_id  INTEGER NOT NULL REFERENCES empresas(id),
        empleado_id INTEGER NOT NULL REFERENCES empleados(id),
        periodo_mes TEXT NOT NULL,
        periodo_anio TEXT NOT NULL,
        estado      TEXT DEFAULT 'A',
        fecha_ini   TEXT,
        fecha_fin   TEXT,
        hs1   REAL DEFAULT 0, inas1 REAL DEFAULT 0, enf1 REAL DEFAULT 0,
        fer1  REAL DEFAULT 0, vac1  REAL DEFAULT 0, ext1 REAL DEFAULT 0,
        hs2   REAL DEFAULT 0, inas2 REAL DEFAULT 0, enf2 REAL DEFAULT 0,
        fer2  REAL DEFAULT 0, vac2  REAL DEFAULT 0, ext2 REAL DEFAULT 0,
        obs         TEXT,
        confirmado  INTEGER DEFAULT 0,
        creado_por  INTEGER REFERENCES usuarios(id),
        creado_en   TEXT DEFAULT (datetime('now')),
        UNIQUE(empresa_id, empleado_id, periodo_mes, periodo_anio)
    );

    CREATE TABLE IF NOT EXISTS audit_log (
        id         INTEGER PRIMARY KEY AUTOINCREMENT,
        usuario_id INTEGER REFERENCES usuarios(id),
        accion     TEXT NOT NULL,
        detalle    TEXT,
        ip         TEXT,
        ts         TEXT DEFAULT (datetime('now'))
    );
    """)
    db.commit()

    # Crear usuario estudio por defecto si no existe
    cur = db.execute("SELECT id FROM usuarios WHERE email = 'clgest@gmail.com'")
    if not cur.fetchone():
        db.execute(
            "INSERT INTO usuarios (email, password, nombre, rol) VALUES (?,?,?,?)",
            ("clgest@gmail.com",
             generate_password_hash("lescgo1"),
             "Estudio CL Gestión", "estudio")
        )
        db.execute(
            "INSERT INTO usuarios (email, password, nombre, rol) VALUES (?,?,?,?)",
            ("clgestad@gmail.com",
             generate_password_hash("lescgo2"),
             "Estudio CL Admin", "estudio")
        )
        # Empresa demo
        db.execute(
            "INSERT INTO empresas (nombre, cuit) VALUES (?,?)",
            ("NASTIQUE OSCAR", "30-12345678-9")
        )
        db.commit()
    db.close()

# ── Helpers ──────────────────────────────────────────────────────

def get_usuario(user_id):
    db = get_db()
    u = db.execute("SELECT * FROM usuarios WHERE id=?", (user_id,)).fetchone()
    db.close()
    return u

def verificar_login(email, password):
    db = get_db()
    u = db.execute("SELECT * FROM usuarios WHERE email=? AND activo=1", (email,)).fetchone()
    db.close()
    if u and check_password_hash(u["password"], password):
        return u
    return None

def get_empresas_usuario(user_id, rol):
    db = get_db()
    if rol == "estudio":
        rows = db.execute("SELECT * FROM empresas WHERE activa=1 ORDER BY nombre").fetchall()
    else:
        rows = db.execute("""
            SELECT e.* FROM empresas e
            JOIN usuario_empresa ue ON ue.empresa_id = e.id
            WHERE ue.usuario_id = ? AND e.activa = 1
        """, (user_id,)).fetchall()
    db.close()
    return rows

def get_empleados(empresa_id, solo_activos=True):
    db = get_db()
    q = "SELECT * FROM empleados WHERE empresa_id=?"
    if solo_activos:
        q += " AND activo=1"
    q += " ORDER BY CAST(legajo AS INTEGER)"
    rows = db.execute(q, (empresa_id,)).fetchall()
    db.close()
    return rows

def get_novedades_periodo(empresa_id, mes, anio):
    db = get_db()
    rows = db.execute("""
        SELECT n.*, e.nombre as emp_nombre, e.legajo, e.jornada, e.categoria
        FROM novedades n
        JOIN empleados e ON e.id = n.empleado_id
        WHERE n.empresa_id=? AND n.periodo_mes=? AND n.periodo_anio=?
        ORDER BY CAST(e.legajo AS INTEGER)
    """, (empresa_id, mes, anio)).fetchall()
    db.close()
    return rows

def guardar_novedad(empresa_id, empleado_id, mes, anio, datos, usuario_id):
    db = get_db()
    db.execute("""
        INSERT INTO novedades
          (empresa_id, empleado_id, periodo_mes, periodo_anio,
           estado, fecha_ini, fecha_fin,
           hs1, inas1, enf1, fer1, vac1, ext1,
           hs2, inas2, enf2, fer2, vac2, ext2,
           obs, creado_por)
        VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
        ON CONFLICT(empresa_id, empleado_id, periodo_mes, periodo_anio)
        DO UPDATE SET
           estado=excluded.estado, fecha_ini=excluded.fecha_ini,
           fecha_fin=excluded.fecha_fin,
           hs1=excluded.hs1, inas1=excluded.inas1, enf1=excluded.enf1,
           fer1=excluded.fer1, vac1=excluded.vac1, ext1=excluded.ext1,
           hs2=excluded.hs2, inas2=excluded.inas2, enf2=excluded.enf2,
           fer2=excluded.fer2, vac2=excluded.vac2, ext2=excluded.ext2,
           obs=excluded.obs, creado_por=excluded.creado_por
    """, (
        empresa_id, empleado_id, mes, anio,
        datos.get("estado","A"), datos.get("fecha_ini"), datos.get("fecha_fin"),
        datos.get("hs1",0), datos.get("inas1",0), datos.get("enf1",0),
        datos.get("fer1",0), datos.get("vac1",0), datos.get("ext1",0),
        datos.get("hs2",0), datos.get("inas2",0), datos.get("enf2",0),
        datos.get("fer2",0), datos.get("vac2",0), datos.get("ext2",0),
        datos.get("obs",""), usuario_id
    ))
    db.commit()
    db.close()

def registrar_log(usuario_id, accion, detalle, ip):
    db = get_db()
    db.execute(
        "INSERT INTO audit_log (usuario_id, accion, detalle, ip) VALUES (?,?,?,?)",
        (usuario_id, accion, detalle, ip)
    )
    db.commit()
    db.close()

def get_audit_log(limite=200):
    db = get_db()
    rows = db.execute("""
        SELECT l.*, u.email, u.nombre as u_nombre
        FROM audit_log l
        LEFT JOIN usuarios u ON u.id = l.usuario_id
        ORDER BY l.ts DESC LIMIT ?
    """, (limite,)).fetchall()
    db.close()
    return rows

def get_usuarios_todos():
    db = get_db()
    rows = db.execute("SELECT * FROM usuarios ORDER BY rol, nombre").fetchall()
    db.close()
    return rows

def crear_usuario(email, password, nombre, rol, empresas_ids):
    db = get_db()
    cur = db.execute(
        "INSERT INTO usuarios (email, password, nombre, rol) VALUES (?,?,?,?)",
        (email, generate_password_hash(password), nombre, rol)
    )
    uid = cur.lastrowid
    for eid in empresas_ids:
        db.execute("INSERT OR IGNORE INTO usuario_empresa VALUES (?,?)", (uid, eid))
    db.commit()
    db.close()
    return uid

def alta_empleado(empresa_id, datos):
    db = get_db()
    # Calcular próximo legajo
    cur = db.execute(
        "SELECT MAX(CAST(legajo AS INTEGER)) as max_leg FROM empleados WHERE empresa_id=?",
        (empresa_id,)
    )
    row = cur.fetchone()
    siguiente = (row["max_leg"] or 0) + 1
    db.execute("""
        INSERT INTO empleados
          (empresa_id, legajo, nombre, cuil, categoria, jornada,
           fecha_ingreso, estado, convenio, cp)
        VALUES (?,?,?,?,?,?,?,?,?,?)
    """, (
        empresa_id, str(siguiente),
        datos["nombre"], datos["cuil"], datos["categoria"],
        datos["jornada"], datos.get("fecha_ingreso"),
        "I", datos.get("convenio","OBREROS DE LA CONSTRUCCION"),
        datos.get("cp","4000")
    ))
    db.commit()
    leg = str(siguiente)
    db.close()
    return leg

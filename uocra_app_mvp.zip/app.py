from flask import (Flask, render_template, request, redirect,
                   url_for, session, jsonify, flash, g)
from functools import wraps
from models import (init_db, verificar_login, get_usuario,
                    get_empresas_usuario, get_empleados,
                    get_novedades_periodo, guardar_novedad,
                    registrar_log, get_audit_log, get_usuarios_todos,
                    crear_usuario, alta_empleado, get_db)
import os

app = Flask(__name__)
app.secret_key = os.environ.get("SECRET_KEY", "uocra-dev-key-cambiar-en-produccion")

# ── Auth helpers ─────────────────────────────────────────────────

def login_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        if "user_id" not in session:
            return redirect(url_for("login"))
        return f(*args, **kwargs)
    return decorated

def estudio_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        if "user_id" not in session:
            return redirect(url_for("login"))
        if session.get("rol") != "estudio":
            flash("Acceso restringido al estudio.", "error")
            return redirect(url_for("dashboard"))
        return f(*args, **kwargs)
    return decorated

def log(accion, detalle=""):
    if "user_id" in session:
        registrar_log(session["user_id"], accion, detalle,
                      request.remote_addr)

# ── Rutas de autenticación ───────────────────────────────────────

@app.route("/login", methods=["GET", "POST"])
def login():
    if "user_id" in session:
        return redirect(url_for("dashboard"))
    error = None
    if request.method == "POST":
        email  = request.form.get("email","").strip().lower()
        clave  = request.form.get("clave","").strip()
        usuario = verificar_login(email, clave)
        if usuario:
            session["user_id"] = usuario["id"]
            session["rol"]     = usuario["rol"]
            session["nombre"]  = usuario["nombre"]
            session["email"]   = usuario["email"]
            registrar_log(usuario["id"], "LOGIN", f"email={email}",
                          request.remote_addr)
            return redirect(url_for("dashboard"))
        else:
            error = "Clave incorrecta o usuario no encontrado."
            registrar_log(None, "LOGIN_FALLIDO", f"email={email}",
                          request.remote_addr)
    return render_template("login.html", error=error)

@app.route("/logout")
def logout():
    log("LOGOUT")
    session.clear()
    return redirect(url_for("login"))

# ── Dashboard ────────────────────────────────────────────────────

@app.route("/")
@login_required
def dashboard():
    empresas = get_empresas_usuario(session["user_id"], session["rol"])
    return render_template("dashboard.html",
                           empresas=empresas,
                           rol=session["rol"],
                           nombre=session["nombre"])

# ── Nómina ───────────────────────────────────────────────────────

@app.route("/nomina/<int:empresa_id>")
@login_required
def nomina(empresa_id):
    db = get_db()
    empresa = db.execute("SELECT * FROM empresas WHERE id=?",
                         (empresa_id,)).fetchone()
    db.close()
    if not empresa:
        flash("Empresa no encontrada.", "error")
        return redirect(url_for("dashboard"))
    empleados = get_empleados(empresa_id)
    log("VER_NOMINA", f"empresa={empresa['nombre']}")
    return render_template("nomina.html",
                           empresa=empresa,
                           empleados=empleados,
                           rol=session["rol"])

@app.route("/empleado/nuevo/<int:empresa_id>", methods=["GET","POST"])
@login_required
def nuevo_empleado(empresa_id):
    db = get_db()
    empresa = db.execute("SELECT * FROM empresas WHERE id=?",
                         (empresa_id,)).fetchone()
    db.close()
    if request.method == "POST":
        datos = {
            "nombre":        request.form["nombre"],
            "cuil":          request.form["cuil"].replace("-","").replace(" ",""),
            "categoria":     request.form["categoria"],
            "jornada":       request.form["jornada"],
            "fecha_ingreso": request.form.get("fecha_ingreso") or None,
            "convenio":      request.form.get("convenio","OBREROS DE LA CONSTRUCCION"),
            "cp":            request.form.get("cp","4000"),
        }
        legajo = alta_empleado(empresa_id, datos)
        log("ALTA_EMPLEADO", f"empresa={empresa_id} nombre={datos['nombre']} legajo={legajo}")
        flash(f"Empleado {datos['nombre']} dado de alta con legajo {legajo}.", "ok")
        return redirect(url_for("nomina", empresa_id=empresa_id))
    return render_template("empleado_form.html", empresa=empresa,
                           rol=session["rol"])

# ── Novedades ────────────────────────────────────────────────────

@app.route("/novedades/<int:empresa_id>")
@login_required
def novedades(empresa_id):
    db = get_db()
    empresa = db.execute("SELECT * FROM empresas WHERE id=?",
                         (empresa_id,)).fetchone()
    db.close()
    mes  = request.args.get("mes",  "")
    anio = request.args.get("anio", "")
    empleados = get_empleados(empresa_id)
    novedades_cargadas = []
    if mes and anio:
        novedades_cargadas = get_novedades_periodo(empresa_id, mes, anio)
    log("VER_NOVEDADES", f"empresa={empresa_id} periodo={mes}/{anio}")
    return render_template("novedades.html",
                           empresa=empresa,
                           empleados=empleados,
                           novedades=novedades_cargadas,
                           mes=mes, anio=anio,
                           rol=session["rol"])

@app.route("/novedades/<int:empresa_id>/guardar", methods=["POST"])
@login_required
def guardar_novedad_route(empresa_id):
    data = request.get_json()
    def flt(v): return float(v) if v not in (None,"") else 0.0

    guardar_novedad(empresa_id, data["empleado_id"],
                    data["mes"], data["anio"],
                    {
                        "estado":    data.get("estado","A"),
                        "fecha_ini": data.get("fecha_ini"),
                        "fecha_fin": data.get("fecha_fin"),
                        "hs1":  flt(data.get("hs1")),
                        "inas1":flt(data.get("inas1")),
                        "enf1": flt(data.get("enf1")),
                        "fer1": flt(data.get("fer1")),
                        "vac1": flt(data.get("vac1")),
                        "ext1": flt(data.get("ext1")),
                        "hs2":  flt(data.get("hs2")),
                        "inas2":flt(data.get("inas2")),
                        "enf2": flt(data.get("enf2")),
                        "fer2": flt(data.get("fer2")),
                        "vac2": flt(data.get("vac2")),
                        "ext2": flt(data.get("ext2")),
                        "obs":  data.get("obs",""),
                    },
                    session["user_id"])
    log("GUARDAR_NOVEDAD",
        f"empresa={empresa_id} empleado={data['empleado_id']} periodo={data['mes']}/{data['anio']}")
    return jsonify({"ok": True, "msg": "Guardado correctamente"})

@app.route("/novedades/<int:empresa_id>/empleado/<int:empleado_id>")
@login_required
def novedad_empleado(empresa_id, empleado_id):
    mes  = request.args.get("mes","")
    anio = request.args.get("anio","")
    db = get_db()
    empresa  = db.execute("SELECT * FROM empresas WHERE id=?", (empresa_id,)).fetchone()
    empleado = db.execute("SELECT * FROM empleados WHERE id=?", (empleado_id,)).fetchone()
    nov = None
    if mes and anio:
        nov = db.execute("""
            SELECT * FROM novedades
            WHERE empresa_id=? AND empleado_id=? AND periodo_mes=? AND periodo_anio=?
        """, (empresa_id, empleado_id, mes, anio)).fetchone()
    db.close()
    return render_template("novedad_form.html",
                           empresa=empresa,
                           empleado=empleado,
                           novedad=nov,
                           mes=mes, anio=anio,
                           rol=session["rol"])

# ── Informe de control ───────────────────────────────────────────

@app.route("/informe/<int:empresa_id>")
@login_required
def informe(empresa_id):
    mes  = request.args.get("mes","")
    anio = request.args.get("anio","")
    db = get_db()
    empresa = db.execute("SELECT * FROM empresas WHERE id=?", (empresa_id,)).fetchone()
    db.close()
    novedades_data = []
    if mes and anio:
        novedades_data = get_novedades_periodo(empresa_id, mes, anio)
    log("VER_INFORME", f"empresa={empresa_id} periodo={mes}/{anio}")
    return render_template("informe.html",
                           empresa=empresa,
                           novedades=novedades_data,
                           mes=mes, anio=anio,
                           rol=session["rol"])

# ── Admin — solo estudio ─────────────────────────────────────────

@app.route("/admin/log")
@estudio_required
def admin_log():
    logs = get_audit_log(300)
    return render_template("admin/log.html", logs=logs, rol=session["rol"])

@app.route("/admin/usuarios")
@estudio_required
def admin_usuarios():
    db = get_db()
    usuarios = get_usuarios_todos()
    empresas = db.execute("SELECT * FROM empresas WHERE activa=1").fetchall()
    db.close()
    return render_template("admin/usuarios.html",
                           usuarios=usuarios, empresas=empresas,
                           rol=session["rol"])

@app.route("/admin/usuarios/nuevo", methods=["POST"])
@estudio_required
def admin_nuevo_usuario():
    email    = request.form["email"].strip().lower()
    password = request.form["password"].strip()
    nombre   = request.form["nombre"].strip()
    rol      = request.form["rol"]
    empresas = request.form.getlist("empresas")
    try:
        uid = crear_usuario(email, password, nombre, rol,
                            [int(e) for e in empresas])
        log("CREAR_USUARIO", f"email={email} rol={rol}")
        flash(f"Usuario {nombre} creado.", "ok")
    except Exception as ex:
        flash(f"Error: {ex}", "error")
    return redirect(url_for("admin_usuarios"))

@app.route("/admin/empresas/nueva", methods=["POST"])
@estudio_required
def admin_nueva_empresa():
    nombre = request.form["nombre"].strip()
    cuit   = request.form.get("cuit","").strip()
    db = get_db()
    db.execute("INSERT INTO empresas (nombre, cuit) VALUES (?,?)", (nombre, cuit))
    db.commit()
    db.close()
    log("CREAR_EMPRESA", f"nombre={nombre}")
    flash(f"Empresa {nombre} creada.", "ok")
    return redirect(url_for("dashboard"))

# ── Init y run ───────────────────────────────────────────────────

if __name__ == "__main__":
    init_db()
    app.run(host="0.0.0.0", port=5000, debug=False)
